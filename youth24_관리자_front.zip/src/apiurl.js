const baseUrl = 'http://localhost:8090'; // 여러개를 한번에 내보낸다.  현재 개발자의 ip 주소를 넣어주면 된다.

export { baseUrl };
