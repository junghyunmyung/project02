package com.policy.admin.search.service;

import com.policy.admin.search.dto.SearchDTO;

public interface SearchService {

	public void searchProcess(SearchDTO searchDTO);
}
