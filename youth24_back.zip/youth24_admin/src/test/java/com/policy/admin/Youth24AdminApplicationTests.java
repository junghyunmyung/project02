package com.policy.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Youth24AdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
